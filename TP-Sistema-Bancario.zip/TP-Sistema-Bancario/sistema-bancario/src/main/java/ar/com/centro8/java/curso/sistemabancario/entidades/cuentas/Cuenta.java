package ar.com.centro8.java.curso.sistemabancario.entidades.cuentas;

import ar.com.centro8.java.curso.sistemabancario.entidades.clientes.Cliente;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter 
@ToString 
@RequiredArgsConstructor 
public abstract class Cuenta {
    private final int numeroCuenta;
    private final Cliente cliente;
    protected float saldo;
     //método
    public void depositarEfectivo(float monto){
        if (monto > 0) {
            saldo += monto;
        }else{
            System.out.println("NO se puede depositar un monto menor o igual a cero");
        }
    }
   //método abstarcto
    public abstract void extraerEfectivo(float monto);

}
