package ar.com.centro8.java.curso.sistemabancario.entidades.clientes;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString (callSuper = true)
public class ClienteIndividual extends Cliente {
    private String nombre;
    private String apellido;
    private String dni;
     //costructor
    public ClienteIndividual(int numeroCliente, String nombre, String apellido, String dni) {
        super(numeroCliente);
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
    }

}
